# Установка Consul

Данная роль устанавливает [Consul](https://www.consul.io/).

Шаги и тэги:

- init: `init`, `consul`, `consul-init`
- conf: `conf`, `consul`, `consul-conf`
- pull: `pull`, `consul`, `consul-pull`
- pull: `up`, `consul`, `consul-up`

## Используемые переменные

- **consul_server** - `true` | `false` запуск в серверном режиме<br>
  default - `false`
- **consul_infra_nodes** - список мастер-хостов `Consul` к которым следует подключатьсяю<br>
  default - `[]`
- **consul_bootstrap_expect** - ожидаемое количество нод в кластере (для `master`-режима)<br>
  default - `1`
- **consul_tag** - тэг docker image `Consul`<br>
  default - `latest`
- **consul_http_rule** - правило для роутинга<br>
  default - `consul.rnds.local`
- **consul_traefik_prefix** - `prefix` для регистрации в `Traefik`<br>
  default - `traefik` 
- **consul_datacenter** - параметр datacenter для `Consul`<br>
  default - `dc1` 
- **consul_dns_port** - порт на котором работает `Consul DNS`.<br>
  default - `8600` 
- **consul_default_dns_recursors** - **Дополнительные** рекурсоры для `Consul DNS`. Основные берутся из `/etc/resolv.conf` на момент прокатки<br>
  default - `'["77.88.8.8"]'` 
  
 
## Пример `inventory`
  
```ini
[all:vars] # Для всех узлов
consul_tag=latest
consul_infra_nodes='["infra-1.rnds.local:8301", "infra-2.rnds.local:8301", "infra-3.rnds.local:8301"]'

# ...

[consul_servers:vars] # Для master-узлов
consul_server=true
```

## Пример `playbook`

### servers.yml

```yaml
- name: Install Servers on consul cluster
  hosts: consul_servers
  serial: 1
  roles:
    - role: shared_roles/consul/consul
      vars:
        consul_bootstrap_expect: '3'
```

### clients.yml

```yaml
- name: Install Clients on consul cluster
  hosts: consul_clients
  roles:
    - role: shared_roles/consul/consul

```
