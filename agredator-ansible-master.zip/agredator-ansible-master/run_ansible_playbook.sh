#!/bin/bash

docker run --rm -it \
    -v "$HOME/.ssh:/root/.ssh" \
    -v "$PWD:/root/project" \
    -v "${SSH_AUTH_SOCK}:/ssh-agent" \
    -e "SSH_AUTH_SOCK=/ssh-agent" \
    artifactory.gitlab.bcs.ru/sentinel.harbor/rnds/ansible \
    ansible-playbook $@
