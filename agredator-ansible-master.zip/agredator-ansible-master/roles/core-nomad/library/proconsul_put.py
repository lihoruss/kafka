#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2022, Vladislav Navrocky <vnavrotskiy@rnds.pro>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
from random import choices
from ansible.module_utils.basic import AnsibleModule
from asyncio import subprocess
import subprocess
import os
import json
__metaclass__ = type

proconsul_image = 'artifactory.gitlab.bcs.ru/sentinel.harbor/rnds/proconsul:2.2.2'

DOCUMENTATION = r'''
---
module: proconsul_put

short_description: Put config to Consul KV with proconsul

version_added: '1.0.0'

description: Put config to Consul KV with proconsul

options:

    consul_url:
        description: consul url (http://consulhost:8500)
        type: str
        required: true
    prefix:
        description: consul kv prefix to put config (services/service1)
        type: str
        required: true
    config:
        description: config as text
        type: str
        required: false
    config_file:
        description: path to config on file system
        type: path
        required: false
    config_format:
        description: explicit format of config (yaml, json)
        type: str
        required: false
    sync:
        description: do sync kv with config
        type: bool
        required: false
        default: false
    override:
        description: do override existing values
        type: bool
        required: false
        default: false
    hidden:
        description: do put hidden keys which names started with a dot
        type: bool
        required: false
        default: false
    disable_envsubst:
        description: do envsubst config before put
        type: bool
        required: false
        default: false
    dry_run:
        description: do not change KV
        type: bool
        required: false
        default: false
    diff_mode:
        description: diff display mode: std, dyff.

author:
    - Vladislav Navrocky (vnavrotskiy@rnds.pro)
'''

EXAMPLES = r'''
- name: Generate config
  set_fact:
    rendered_config: "{{ lookup('template', '%s/files/config.yml' % (role_path)) }}"
- name: Put config to KV
  proconsul_put:
    consul_url: "{{ consul_url }}"
    config: "{{ rendered_config }}"
    config_format: "yaml"
    prefix: "{{ kv_prefix }}"
    sync: true
    override: true
    disable_envsubst: true
'''


def main():

    module_args = dict(
        consul_url=dict(type='str', required=True),
        prefix=dict(type='str', required=True),
        config=dict(type='str', required=False),
        config_file=dict(type='path', required=False),
        config_format=dict(type='str', required=False),
        sync=dict(type='bool', required=False, default=False),
        skip_empty=dict(type='bool', required=False, default=False),
        dont_sync_rx=dict(type='str', required=False),
        override=dict(type='bool', required=False, default=False),
        hidden=dict(type='bool', required=False, default=False),
        disable_envsubst=dict(type='bool', required=False, default=False),
        dry_run=dict(type='bool', required=False, default=False),
        diff_mode=dict(type='str', required=False,
                       default='std', choices=['std', 'dyff'])
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    result = dict(
        changed=False,
    )

    consul_url = module.params['consul_url']
    prefix = module.params['prefix']
    config = module.params['config']
    config_file = module.params['config_file']
    config_format = module.params['config_format']
    sync = module.params['sync']
    skip_empty = module.params['skip_empty']
    dont_sync_rx = module.params['dont_sync_rx']
    override = module.params['override']
    hidden = module.params['hidden']
    disable_envsubst = module.params['disable_envsubst']
    dry_run = module.params['dry_run']
    diff_mode = module.params['diff_mode']

    def run_proconsul(additional_args):

        input = None

        docker_args = [
            '--rm'
        ]

        common_args = [
            '--consul', consul_url,
            '--prefix', prefix,
        ]

        if config:
            input = str.encode(config, 'utf-8')
            docker_args += ['-i']
            common_args += ['--config', '-']

        if config_file:
            file_name = os.path.basename(config_file)
            docker_args += ['-v', '%s:/%s' % (config_file, file_name)]
            common_args += ['--config', '/%s' % (file_name)]

        if config_format:
            common_args += ['--format', config_format]

        if sync:
            common_args += ['--sync']

        if skip_empty:
            common_args += ['--skip-empty']

        if dont_sync_rx:
            common_args += ['--dont-sync-rx', dont_sync_rx]

        if override:
            common_args += ['--override']

        if hidden:
            common_args += ['--hidden']

        if disable_envsubst:
            common_args += ['--disable-envsubst']

        return subprocess.check_output(['docker', 'run'] + docker_args + [proconsul_image, 'put'] + common_args + additional_args, input=input)

    if diff_mode == 'std':
        json_out = run_proconsul(['--ansible-diff'])
        diff = json.loads(json_out)

        addr = 'consul=%s, kv_prefix=%s' % (consul_url, prefix)
        diff['before_header'] = addr
        diff['after_header'] = addr

        result['diff'] = diff
        result['changed'] = diff['before'] != diff['after']

    elif diff_mode == 'dyff':
        out = run_proconsul(['--diff']).decode('utf-8')

        addr = 'consul=%s, kv_prefix=%s' % (consul_url, prefix)
        diff = dict(
            before='',
            before_header='',
            after_header=addr,
            after=out
        )
        result['changed'] = out.strip(' \n\t') != ''

        result['diff'] = diff

    else:
        raise ValueError('Unsupported diff mode: %s' % (diff_mode))

    if module.check_mode:
        module.exit_json(**result)

    additional_args = []
    if dry_run:
        additional_args += ['--dry-run']

    result['proconsul_output'] = run_proconsul(additional_args=additional_args)

    module.exit_json(**result)


if __name__ == '__main__':
    main()
