#!/bin/sh

set -ex

env

cat /etc/hosts

cat /tmp/configs/config.yaml
cat /tmp/configs/db.json

consul services deregister -http-addr=${CONSUL_HTTP_ADDR} /tmp/configs/db.json | exit 0
consul services register -http-addr=${CONSUL_HTTP_ADDR} /tmp/configs/db.json

exec proconsul --consul=${CONSUL_HTTP_ADDR} -d put --prefix ${CONSUL_KV_NAMESPACE}services/env --override --config /tmp/configs/config.yaml
