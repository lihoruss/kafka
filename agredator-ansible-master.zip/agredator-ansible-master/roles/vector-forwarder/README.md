### Описание

Форвардер vector логов слушает сокет докера и отправляет все логи на машину (172.22.4.33), где логи собирает агрегатор логов. 
Перед тем как деплоить форвардер необходимо настроить агрегатор, чтобы он слушал на отдельном порту (логи с определенной машины агрегатор принимает на определенном порту). 
Необходимо в агрегаторе настроить источник получения логов, а также туда куда будем сохранять логи (sink, раковина в терминологии vector) в агрегаторе.
Пример настройки источника

```
[sources.agg-cloud-in]
  type = "vector" # required
  address = "0.0.0.0:9095"
```

Пример настройки sink (раковины, куда будут сохраняться логи)

```
[sinks.agg-cloud-out]
  encoding.codec = "ndjson"
  inputs = ["agg-cloud-in"]
  type = "file"
  path = "/etc/vector/logs/agg-cloud/{{ host }}/{{ container_name }}-%Y-%m-%d.log"
```

### Деплой vector (форвардер логов)

`vector_aggregator_port` это переменная, которая настраивается в источнике vector агрегатор.

```
ansible-playbook playbook/vector-forwarder.yml -i inventory/cloudprod.ini -e vector_aggregator_port=9095 -DC
```
