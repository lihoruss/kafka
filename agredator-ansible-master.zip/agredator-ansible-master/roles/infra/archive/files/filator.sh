#!/bin/sh

# завершаем скрипт в случае любой ошибки
set -e

# экспортим переменные дл включения trace-режима bash
export AWS_ACCESS_KEY_ID=${AWS_KEY}
export AWS_SECRET_ACCESS_KEY=${AWS_SECRET}

# включаем trace-режим
set -x

export CURRENT_IP={{ '{{ env "meta.CURRENT_IP" }}' }}
export FILATOR_HOSTNAME=`echo "${FILATOR_URL}" | awk -F/ '{print $3}'`

# используем DNS-для-бедных чтоб ходить на траевик на localhost и использовать mesh
echo "${CURRENT_IP} ${FILATOR_HOSTNAME}" >> /etc/hosts

# работать будем во временной папке
DIR=`mktemp -d`
cd $DIR

# 1. Создаём транзакцию и получаем её uuid
TX=`curl -X POST "${FILATOR_URL}/attachments/archive/tx"`
echo "TX:"
echo $TX | jq

TX_UUID=`echo $TX | jq -r .uuid`

# 2. Скачиваем файл архива в рамках транзакуии
wget "${FILATOR_URL}/attachments/archive/${TX_UUID}.zip" --content-disposition

# печатаем статистику о том сколько строк было скачано
curl "${FILATOR_URL}/attachments/archive/tx/${TX_UUID}" | jq

# 3. Грузим файл архива в S3

# находим файл по имени
FILE=`ls | grep attachments_le | head -n 1`

if [ -f "${FILE}" ]; then
  # если он есть - грузим
  echo "Uploading backup file ${FILE}..."
else
  # если нет - сервер вернул 204 NO_CONTENT, потому что за выбранную дату архва данных в БД уже нет
  echo "There is no data for this period"
  exit 0
fi

PREFIX=`date "+%Y-%m-%d/%H-%M-%S"`
# грузим файл в S3
aws --no-verify-ssl --endpoint-url ${AWS_ENDPOINT}  s3 cp ./${FILE} s3://${BUCKET}/filator/${PREFIX}/${FILE}

# проверяем что файл загрузился в S3
aws --no-verify-ssl --endpoint-url ${AWS_ENDPOINT} s3 ls s3://${BUCKET}/filator/${PREFIX}/${FILE}

# ЗАКРЫВАЕМ (удаляем) транзакцию - в этотм момент удалятся данные
MESSAGE="Deleted by scheduled job at `date`"
curl -X DELETE --data-urlencode "message=${MESSAGE}" "${FILATOR_URL}/attachments/archive/${TX_UUID}"