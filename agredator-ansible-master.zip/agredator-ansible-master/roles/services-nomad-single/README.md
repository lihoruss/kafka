# Запуск сервисов Aggredator в Nomad

Эта роль запуска в `nomad` `job` с сервисами Aggredator.

## СМЭВ3

Для добавления очередного клиента необходимо в `inventory/group_vars/all.yml` добавить конфигурацию для конкретного клиента.

Пример добавления клиента:

```
inventory: 
  cloudtest: 
    smev_clients:
      rnds-test:
        smev3_service_image: 'artifactory.gitlab.bcs.ru/sentinel.harbor/aggredator/smev3'
        smev3_service_tag: '13aab36c'
        smev3_use_prometheus: false
        smev3_smev_endpoint: "http://smev3-n0.test.gosuslugi.ru:7500/smev/v1.2/ws?wsdl"
        smev3_service_use_production: "true"
    another-client:
    another-yet-client:
```

Для конфигурирования сервиса используются переменные с префиксом `smev3_`. Приоритет получения значения переменной следующий:

1. Из `inventory/<instance>/smev_clients/<client>`
2. Из глобальной переменной в `inventory`
3. Из `defaults/main.yml` в роли

## Имя базы данных

Имя можно задать несколькими способами. По умолчанию шаблон имени берется из переменной `smev3_service_database_name_template` и
выглядит примерно так 

```
smev3_service_database_name_template: "aggredator-service-smev3-%s"
```

`%s` - в это место подставляется имя клиента

Шаблон можно перебить глобально или для конкретного клиента (см. приоритет использования переменных выше).

Также есть переменная `smev3_service_database_name`, которая явно задает имя БД для СМЕВ сервиса клиента, её следует указывать в 
конкретной конфигурации клиента в `inventory/<instance>/smev_clients/<client>`.