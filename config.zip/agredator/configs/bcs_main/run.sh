#!/bin/bash

set -ex.

source .env

envsubst < infra/.env.in > infra/.env
envsubst < core/.env.in > core/.env
envsubst < services/.env.in > services/.env
(cd infra && ./run.sh)
(cd core && ./run.sh)
(cd services && ./run.sh)

