#!/bin/bash

set -ex 

docker-compose pull || true

./update_config.sh
./bootstrap.sh

docker-compose up -d

