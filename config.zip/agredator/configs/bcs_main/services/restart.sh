#!/bin/bash

set -ex 

docker-compose restart



