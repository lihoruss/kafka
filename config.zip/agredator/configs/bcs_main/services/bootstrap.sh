#!/bin/bash

set -ex 

docker exec -e BOOTSTRAP_CLIENTS="smev3,esia-register,uprid3,fns-inn,zhkh-export-document,zhkh-export-receivers,zhkh-import-notifications,epgu-adapter,epgu-pfr-account,epgu-ndfl2,epgu-simplified-tax,mvd-pass2,esia-personal-data" bcs_main_core_admin_1 /home/app/docker/bootstrap.sh

