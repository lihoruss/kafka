#!/bin/bash

set -ex 

docker-compose pull
docker-compose up -d
docker-compose exec -T consul proconsul -t 30 --consul http://localhost:8500 exec --depend="db,redis" -- echo "db and redis is ready"

