#!/bin/bash

set -ex 

./update_config.sh
./bootstrap.sh

docker-compose up -d

