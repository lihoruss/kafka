#!/bin/bash

set -ex 

docker-compose run --rm -T --use-aliases -e BOOTSTRAP_CLIENTS="apigw" admin /home/app/docker/bootstrap.sh

