#!/bin/bash

set -ex 

docker-compose run --rm -T admin proconsul --consul http://consul:8500 put --prefix services/env/ --override --config - < ../config.yaml

