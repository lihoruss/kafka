# Nomad

Внутренняя инфраструктура поддерживается в [этом](https://hera.rnds.pro/pages/viewpage.action?pageId=28841600) документе. 

Пример плейбуков, которые настраивают кластер [Nomad](https://www.nomadproject.io/) для инфраструктуры разработки.

```bash
example_playbooks/nomad
├── all.yml
├── clients.yml
└── servers.yml
```

## Использование

Для того чтобы раскатать всё правильно надо выполнить команду:

```bash
ansible-playbook -i inventory/hosts.ini playbook/nomad/all.yml -D
```

Никаких фильтров при таком использовании не требуется. 

### Раскатка мастер и агентских узлов по-отдельности

Данное действие можно сделать с помощью стандартной фильтрации `-l <host>`, однако предпочтительным способом является использование соответствующего плейбука:

```bash
# фильтруются по группе "nomad_servers" в файле плейбука
ansible-playbook -i inventory/hosts.ini playbook/nomad/servers.yml -D
# фильтруются по группе "nomad_clients" в файле плейбука
ansible-playbook -i inventory/hosts.ini playbook/nomad/clients.yml -D
```

## Параметры

Всё что необходимо для запуска/обновления кластера задаётся в файле инвентаря, в соответствующих группах:

- группа `nomad_servers` - мастер-узлы кластера `Nomad`
- группа `nomad_clients` - агентские узлы кластера `Nomad`

Параметры конкретных узлов настраиваются через переменные, непосредственно применяемые к мастер или агентским узлам.

### Настройка/разметка параметров мастер-узла

Пример:

```ini
[infra]
infra-1 datacenter="sphere"
infra-2 datacenter="circle"
infra-3 datacenter="selectel"

[nomad_servers:children]
infra

[nomad_servers:vars]
nomad='{"server": {"expect": 3}, "meta": {"dev": true}}'
```

### Настройка/разметка параметров агентского узла

Пример:

```ini
[sentinel]
sentinel-test nomad='{"meta": {"sentinel": true, "dev": true, "test": true}}'
sentinel-mr   nomad='{"meta": {"sentinel": true, "dev": true, "mr": true}}'

[nomad_clients:children]
sentinel
agg_services
```
