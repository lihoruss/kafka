# Общие роли Ansible

Этот проект является общей библиотекой ролей Ansible.  

## Подключение к своему проекту Ansible

### Через git submodule

```bash
git submodule add git@br.rnds.pro:rnds/shared-ansible-roles.git ansible/shared_roles
```

При клонировании проекта с submodule не забываем указывать флаг `--recurse-submodules`:

```bash
git clone --recurse-submodules git@br.rnds.pro:rnds/my-cool-ansible-project.git
```

Соответственно в своих плейбуках пишем путь к роли таким образом:
```yaml
---
- name: Install docker and docker-compose
  hosts: all
  become: yes
  roles:
    - { role: shared_roles/docker }
    - { role: shared_roles/docker-compose }
```

Воркфлоу по изменению общей роли следующий:

1. Делаем ветку по задаче в сабмодуле `shared_roles`: <feature|bugfix>/TASK-111-description
2. Коммитим изменения в сабмодуле
3. Заливаем ветку
4. Делаем MR
5. Коммитим свои изменения в основном репозитории
6. Ревьювим и принимаем MR в `ansible_shared_roles`

## Обновление submodules

Для обнволения надо выполниить следующее:

```bash
git submodule update --init --recursive
```

## Добавление новой роли из другого проекта с сохранением истории коммитов

Можно добавить существующую роль из другого репозитория с сохранением истории коммитов используя git subtree следующим образом:

Процесс на примере [`rnds/maintenance`](https://br.rnds.pro/rnds/maintenance) и роли `docker`:

```bash
# добавляем в свой проект remote на репозиторий-источник
git remote add -f sourcerepo git@br.rnds.pro:rnds/maintenance.git

# переключаемся на исходники репозитория-источника
git checkout -b staging-branch sourcerepo/master

# вычленяем коммиты по нужной папке в отдельную ветку 
git subtree split -P ansible/roles/docker -b docker

# переключаемся назад на наши исходники
git checkout master

# добавляем коммиты из ветки docker себе в папку docker
git subtree add -P docker docker

# удаляем более ненужные ветки и remote
git branch -D docker staging-branch
git remote rm sourcerepo
```

Оригинальная статья: https://jrsmith3.github.io/merging-a-subdirectory-from-another-repo-via-git-subtree.html
