# Установка consul-registrator

Данная роль устанавливает [consul-registrator](https://gliderlabs.github.io/registrator/latest/).

Шаги и тэги:

- init: `init`, `registrator`, `registrator-init`
- conf: `conf`, `registrator`, `registrator-conf`
- pull: `pull`, `registrator`, `registrator-pull`
- pull: `up`, `registrator`, `registrator-up`

## Используемые переменные

## Пример `inventory`
  
## Пример `playbook`

```yaml
- name: Install consul-registrator
  hosts: all
  roles:
    - role: shared_roles/consul/registrator
```
