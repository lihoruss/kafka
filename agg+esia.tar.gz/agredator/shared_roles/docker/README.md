# Установка docker

Данная роль устанавливает `docker`, и при необходимости авторизуется в указанный приватный `docker registry`.

Тэги:

- docker
- docker-install
- docker-login
- docker-conf

По тэгам можно фильтрануть установку.

Необходимые переменные среды:

- **default_address_pools_base** - размер пула адресов, которые под себя резервирует docker. По умолчанию: 10.11.0.0/16
- **default_address_pools_size** - маска сети докера. По умолчанию: 24
- **docker_registry_host** - URL приватного docker registry. Если эта переменная не задана, то авторизация не производится.
- **docker_registry_user** - логин
- **docker_registry_password** - пароль

Количество возможных сетей вычисляется по формуле:

```
2 ^ (default_address_pools_size - default_address_pools_base.mask)
2 ^ (24 - 16) = 256
```

Количество контейнеров в одной сети вычисляется по формуле:

```
2 ^ (32 - default_address_pools_size)
2 ^ (32 - 24) = 256
```

Пример плейбука:

```yaml
---
- name: Install docker and docker-compose
  hosts: all
  become: yes
  vars_files: ../../inventory/vault.yml
  vars:
    docker_registry_host: "harbor.rnds.pro"
    docker_registry_user: "agg"
  roles:
    - { role: shared_roles/docker }
    - { role: shared_roles/docker-compose }
```
