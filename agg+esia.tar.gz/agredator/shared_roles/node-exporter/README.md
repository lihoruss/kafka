# Роль для провижининга Node exporter

### 

Пример с датацентрами в inventory:

```ini
node_exporter_datacenters='"zone-a", "zone-b", "zone-c"'
```

Пример с одном датацентром

```bash
ansible-playbook playbook/infra/node-exporter.yml -i inventory/cloudprod2.ini -e instance=prod -e node_exporter_datacenters=zone-a -l cloud-infra-a -D
```
Пример с несколькими датацентрами

```bash
ansible-playbook playbook/infra/node-exporter.yml -i inventory/cloudprod2.ini -e instance=prod -e "node_exporter_datacenters=\"zone-b\",\"zone-a\"" -l cloud-infra-a -D
```


