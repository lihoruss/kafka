# Дистрибутив Агредатор

Содержит в себе все необходимые компоненты для развертывания кластера Агредатор. 

# Описание установки Aggredator

Перед установкой сборки необходимо поправить файл inventory/box/hosts.ini под параметры своей инфраструктуры. (В файле заменить все IP 192.168.56.4 на свой)

Некоторые параметры в файле hosts.ini

domain - ваш базовый домен в вашей инфраструктуре

inventory_name - (Например: rndaggredator) префикс для доступа к инфраструктурным сервисам. В итоге будет consul.rndaggredator.bank.srv, nomad.rndaggredator.bank.srv, traefik.rndaggredator.bank.srv.  С помошью этого параметра можно разделить в вашей инфраструктуре тестовое облако и продуктивное

Например:
  - rndaggredator.bank.srv продуктовый контур
  - aggtest.bank.srv тестовый контур

apigw_domain - указываем домен для обращения к apigw. (лучшим решением будет использовать apigw.rndaggredator.bank.srv) но можно и rndaggredator.bank.srv


## Установка

1. ansible-playbook -i inventory/box/hosts.ini playbook/infra.yml -D
2. ansible-playbook -i inventory/box/hosts.ini playbook/infra/db.yml -D (Нужно если не используете свою БД)
3. Установка Ядра системы (Core):
     1) ansible-playbook -i inventory/box/hosts.ini playbook/core.yml -D
4. Установка сервисов:
   ansible-playbook -i inventory/box/hosts.ini playbook/services.yml -D
