# Конфигурирование клиентских доступов к сервисам через Traefik

Данная роль загружает клиентские конфиги Traefik в Consul KV. Сами конфиги должны быть в YAML формате и лежать в папке `inventory`.
Сами конфиги при загрузке прогоняются через шаблонизатор Ansible.

Есть общая задача, которая грузит все файлы из указанной папки и специфичная которая генерит конфиг из описания клиентов.

Необходимые переменные среды:

- **traefik_clients_config** - конфиг из которого генерятся конфиги [клиентов](./tempaltes/clients.yml.j2)
- **rnds_office_ip** - лющий список внутренних (разрешенных) IP-адресов
- **traefik_clients_inventory_dir** - папка в inventory, содержащая конфиги
- **traefik_clients_consul_url** - URL consul в который необходимо загрузить конфиги
- **traefik_clients_consul_prefix** - путь в KV куда загружать

Роль запускается только на нодах с взведенным флагом `docker_runner`.

Пример запуска:

```bash
ansible-playbook -i inventory/cloudtest/hosts.ini  playbook/infra/traefik/traefik-clients.yml -DC
```