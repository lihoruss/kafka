# Установка aggredator-db

Данная роль устанавливает `aggredator-db` и настраивает в ней одну базу данных.

Тэги:

- db
- db-init
- db-conf
- db-pull
- db-up
- db-wait

Необходимые переменные среды:

- **db_tag** - тэг docker образа
- **db_name** - имя базы данных
- **db_user** - пользователь
- **db_password** - пароль

Пример плейбука:

```yaml
---
- name: Install database
  hosts: db
  become: yes
  roles:
    - { role: roles/infra/database }
```