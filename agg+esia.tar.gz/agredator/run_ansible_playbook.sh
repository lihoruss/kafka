#!/bin/bash

docker run --rm -it \
    -v "$HOME/.ssh:/root/.ssh" \
    -v "$PWD:/root/project" \
    -v "${SSH_AUTH_SOCK}:/ssh-agent" \
    -e "SSH_AUTH_SOCK=/ssh-agent" \
    harbor.rnds.pro/rnds/ansible \
    ansible-playbook $@
