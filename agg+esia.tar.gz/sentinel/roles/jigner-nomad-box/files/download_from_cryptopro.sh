#!/bin/bash

set -e

# example: system/files/private/csp/50/12000/linux-ia32_deb.tgz
URL=$1 

LOGIN=${LOGIN:-}
PASSWORD=${PASSWORD:-}

urlencode() {
    # urlencode <string>

    old_lc_collate=$LC_COLLATE
    LC_COLLATE=C

    local length="${#1}"
    for (( i=0; i < length; i++ )); do
        local c="${1:$i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf '%s' "$c" ;;
            *) printf '%%%02X' "'$c" ;;
        esac
    done

    LC_COLLATE=$old_lc_collate
}

FILENAME=$(basename ${URL})
ENCODED_URL=$(urlencode "${URL}")

[ -f "${FILENAME}" ] && exit 0

curl -L --fail -b cookies.txt "https://cryptopro.ru/user/login?destination=${ENCODED_URL}" \
  --data-urlencode "name=${LOGIN}" \
  --data-urlencode "pass=${PASSWORD}" \
  --data-urlencode 'form_id=user_login' \
  --output "${FILENAME}"

if grep "<!DOCTYPE HTML>" "${FILENAME}"; then
  echo "Download error"
  rm "${FILENAME}"
  exit 1
fi
