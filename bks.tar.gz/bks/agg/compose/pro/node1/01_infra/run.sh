#!/bin/bash

export ARGS_TMP="${@}"

source ./prepare

set -ex

docker network create agg_${AGGREDATOR_INSTANCE}_bus || true

echo 'Fix folder permissions to Redis(KeyDB) service'
mkdir -p ${STORAGE_PREFIX}/${AGGREDATOR_INSTANCE}/keydb/data
chown -R 999:999 ${STORAGE_PREFIX}/${AGGREDATOR_INSTANCE}/keydb/data

${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} pull
exec ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} up -d --remove-orphans ${ARGS_TMP}