#/bin/bash

set -ex 

cp inventory.example ../inventory
cp .env.core.example ../.env.core
cp .env.services.example ../.env.services