#!/bin/bash

source ./prepare

set -ex

${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} rm -fsv configurator || true
exec ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} run --rm -T configurator