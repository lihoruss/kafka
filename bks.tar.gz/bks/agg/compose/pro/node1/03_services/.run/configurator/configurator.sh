#!/bin/sh

set -ex

envsubst < /tmp/configs/configurator.yaml.in > /tmp/configurator.yaml

curl -iv -u "$ADMIN_API_USER:$ADMIN_API_PASS" --retry 5 --retry-delay 5 --retry-all-errors -f http://admin.agg.local/api/certificates/bootstrap?client=${BOOTSTRAP_CLIENTS}

proconsul --consul=${CONSUL_HTTP_ADDR} put --diff --override --prefix ${CONSUL_KV_NAMESPACE}services/env/ --config /tmp/configurator.yaml
exec proconsul --consul=${CONSUL_HTTP_ADDR} put --override --prefix ${CONSUL_KV_NAMESPACE}services/env/ --config /tmp/configurator.yaml

