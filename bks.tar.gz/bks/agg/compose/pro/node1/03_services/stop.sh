#!/bin/bash

export ARGS_TMP="${@}"

source ./prepare

set -ex
  
exec ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} down --remove-orphans -t 30 ${ARGS_TMP}
