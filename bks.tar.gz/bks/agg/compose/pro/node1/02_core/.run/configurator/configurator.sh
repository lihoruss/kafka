#!/bin/sh

set -ex

envsubst < /tmp/configs/configurator.yaml.in > /tmp/configurator.yaml

proconsul --consul=${CONSUL_HTTP_ADDR} put --diff --override --prefix ${CONSUL_KV_NAMESPACE}services/env/ --config /tmp/configurator.yaml
exec proconsul --consul=${CONSUL_HTTP_ADDR} put --override --prefix ${CONSUL_KV_NAMESPACE}services/env/ --config /tmp/configurator.yaml

