#!/bin/bash

export ARGS_TMP="${@}"

source ./prepare

set -ex

  ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} rm -fsv configurator || true
  ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} run --rm -T configurator
    
  ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} pull
  exec ${COMPOSE_DRIVER} ${COMPOSE_PROFILES_CMD} up -d --remove-orphans  ${ARGS_TMP}

