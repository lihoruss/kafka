# Инструкция по установке коробочного решения
## Требования

Здесь описаны требования, предъявляемые платформой `ЕСИА Шлюз` к IT-инфраструктуре, в которую планируется интеграция. Поскольку платформа представляет собой комплексное и конфигурируемое решение, то данные требования носят консультационный характер и могут меняться в зависимости от конкретной выбранной схемы размещения или иных условий.

## Системные требования

Работает на любой современной операционной системе семейства Linux и на любой современной версии Docker.

Поскольку требования к аппаратной части сильно зависят от планируемой загрузки (и выбранной схемы размещения), то тут будут приведены минимальные характеристики.

Минимальные требования к аппаратной части:

- 2CPU;
- 4GB Memory;
- 100GB Disk [^disk].

[^disk]: `ЕСИА Шлюз` не занимаются хранением данных сами по себе, при необходимости что-то сохранить используются базы данных. Таким образом объем диска требуется только для размещения и запуска самих сервисов и их образов `Docker`.

Минимальные требования к аппаратной части БД:

- 2CPU;
- 4GB Memory.

## Технические особенности

Программное обеспечение `ЕСИА Шлюз` поставляется в виде архива с Ansible скриптами.

_Ansible это система управления конфигурациями, написанная на языке программирования Python, с использованием декларативного языка разметки для описания конфигураций. Используется для автоматизации настройки и развертывания программного обеспечения._

При развертывании используется Nomad.

_Nomad это система оркестрации docker контейнеров от HashiCorp, написанная на Golang._

## Безопасность

Требования к безопасности в существенной степени определяются окружением клиента и принятыми внутренними регламентами, уставными документами и иными нормативными и законодательными актами.

## Хранение данных

`ЕСИА Шлюз` не хранит данные локально и представляет из себя `read-only` контейнеры. Все данные сохраняются в строго определенных местах: `PostgreSQL` и `Redis`, которые в свою очередь не являются частью ПО и могут быть настроены и запущены силами специалистов заказчика согласно установленным нормам.

Кроме того, `ЕСИА Шлюз` спроектирован так, чтобы во время работы `не сохранять персональные данные`, с которыми он работает, а хранить лишь информацию о выполненной работе - какой запрос как именно был обработан.

## Конфигурация
### Конфигурирование хост-машины

Для запуска `ЕСИА Шлюз` можно использовать современную ОС семейства Linux. Тем не менее есть примерные требования, которые гарантируют нормальную работу и простоту запуска, поскольку они используются при разработке и тестировании платформы.

- ОС: Debian 9.5 (x86-64) или выше, Ubuntu 18.04 (x86-64) или выше;
- Наличие на машине доступа к harbor.rnds.pro, hub.docker.com по протоколу HTTPS на порт 443 для скачивания Docker образов сервисов;
- [Ansible](https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html) версии не менее 2.9;
- [Плагин для работы с докером в Ansible](https://galaxy.ansible.com/community/docker);
- [Python 3](https://www.python.org/downloads/).

### Конфигурирование сервиса через Ansible inventory

Конфигурирование сервиса выполняется через Ansible inventory. Перед стартом развертывания сервиса необходимо подготовить следующие данные и заполнить их в файле инвентаря по пути inventory/box.ini

- Доменное имя, по которому будет доступен `ЕСИА Шлюз`;
- Hostname машин(ы) на котороых будет происходить развертывание `ЕСИА Шлюз`;
- Данные для подключения к базе данных PostgreSQL:
    - database_host - IP Address;
    - database_port - IP Port;
    - database_username - User;
    - database_password - Password;
    - Приложение использует 2 базы данных:
      - database_tech_db_name - Имя технической базы, необходимой для работы фоновых задач;
      - database_main_db_name - Имя основной базы, необходимой для работы приложения;
- Сервис Redis:
    - redis_host - IP Address;
    - redis_port - IP Port.

### Установка ПО

Архив Ansible скриптов содержит команды для установки всех необходимых зависимостей и инфраструктуры для работы `ЕСИА Шлюза`.

Ниже приведен список всех команд в правильной последовательности для успешного разворачивания коробочного решения:

#### 1. Подготовка хост системы перед разворачиванием приложения
Перед установкой системы на хост, необходимо произвети перевоначальную настройку ОС а также файл инвентаря по пути inventory/box.ini

- Убедиться в правильной установк времени и часового пояса системы.
- Обновить систему пакетным менеджером до последней стабильной версии:  

      apt-get update && apt-get upgrade

#### 2. Установка системного ПО
```bash
ansible-playbook -i inventory/box_single_host.ini playbook/system/all.yml -D
```
В состав системного ПО входят следующие пакеты:

   - docker
   - docker-compose
   - docker registry

Установка пакетов по отдельносьти можно осуществить слудующими командами:

##### 2.1. Устанавливаем приложения `docker` и `docker-compose` на хост
```bash
ansible-playbook -i inventory/box_single_host.ini playbook/system/docker.yml -l all -D
```
##### 2.2. Устанавливаем приложение `docker registry` на хост
```bash
ansible-playbook -i inventory/box_single_host.ini playbook/system/docker-registry.yml -l all -D
```

#### 3. Установка ПО поддержки инфраструктуры приложения
```bash
ansible-playbook -i inventory/box_single_host.ini playbook/infra/all.yml -D
```

В состав ПО инфраструктуры входят следующие пакеты:

  - consul 
  - nomad
  - redis
  - db
  - registrator
  - traefik

Установка пакетов по отдельносьти можно осуществить слудующими командами:

##### 3.1. Устанавливаем Consul (service discovery) на хост
```bash
ansible-playbook -i inventory/box_single_host.ini playbook/infra/consul.yml -D
```
##### 3.2. Устанавливаем Nomad (система оркестрации)
```bash
ansible-playbook playbook/nomad.yml -i inventory/box_single_host.ini -D
```
Убеждаемся что Nomad запущен.

> systemctl status nomad

В случае отсутствия ошибок запуска сервиса, на порту 4646 хоста установки должен появиться WEB интерфес Nomad.

###### 3.3.1. В случае отсутствия развернутых на стороне заказчика сервисов Redis и PostgreSQL перед дальнейшей установкой (для тестирования работоспособности сервиса) необходимо их установить.
⚠️ ***Важно:*** База данных PostgreSQL и Redis поставляемая в коробочном решении не может применяться в боевом режиме. Весь риск и последтвия использования тестовых баз данных лежат на заказчике.

```bash
ansible-playbook playbook/infra/db.yml -i inventory/box_single_host.ini
ansible-playbook playbook/infra/redis.yml -i inventory/box_single_host.ini
```
##### 3.4. Ставим Registrator (Сервис обнаружения микросеврсисов для Consul (service discovery))
```bash
ansible-playbook playbook/infra/registrator.yml -i inventory/box_single_host.ini -D
```
##### 3.5. Ставим Traefic (Web Proxy)
```bash
ansible-playbook playbook/infra/traefik-nomad.yml -i inventory/box_single_host.ini -D
```
#### 4. Конфигурируем Tenats
```bash
ansible-playbook playbook/add-tenants.yml -i inventory/box_single_host.ini -D
```
#### 5. Ставим SentinelApp
```bash
ansible-playbook playbook/sentinel-nomad.yml -i inventory/box_single_host.ini -e replicas=1 -e deploy_tag=latest -D
```
  > 📝 Важно! После выполнения команды установки SentinelApp, необходимо выждать время необходимое для запуска сервисов.


#### 6. Ставим Jigner (сервис для подписания запросов)
```bash
ansible-playbook playbook/jigner-nomad-box.yml -i inventory/box_single_host.ini -D
```

Постнастройка и проверка работы сервиса изложена в следующей документации, по адресу:
https://wiki.esia.pro/docs/jigner_box/

#### ПРИЛОЖЕНИЕ А. Содержимое файла Ansible inventory
```yaml
# Имя домена, по которому шлюз будет доступен из сети Интернет
domain=esia.example.org

# Database config
# IP адрес по которому будет доступна база данных
database_host=10.10.10.10
# Порт по которому будеть доступна база данных Postgresql (по умолчанию 5432)
database_port=5432
# Имя пользователя для подключения к Postgresql (по умолчанию postgres)
database_username=postgres
# Пароль для подключения к Postgresql (тот который использовался при разворачивании postgresql)
database_password=password
# Число потоков подключения к базе (по умолчанию 10)
database_pool=10
# Имя базы данных (для технических нужд приложения, можно не менять)
database_tech_db_name=esia_default_db
# Имя базы данных (для основных настроек, можно не менять)
database_main_db_name=esia_main_db

# Config for Consul Catalog
# IP адрес на котором будет развернут ведущий Consul сервис
consul_host=10.10.10.10
# Порт для взаимодействия с Consul (обычно 8500)
consul_port=8500

# Заполнять приложение тестовыми данными
app_need_seed=true

# Settings for connect to redis
# IP адрес хоста на котором доступен сервис Redis (не может быть localhost)
redis_host=10.10.10.11
# Порт по которому доступен сервис Redis (обычно 6379)
redis_port=6379
# Пароль для подключения к сервису Redis
redis_pass=password

# SMTP Config APP options
app_smtp_user_name=esia@domain.ru
app_smtp_port=465
app_smtp_password=password
app_smtp_address=mail.domain.ru

# Пароль администратора
app_main_admin_password=password

# Доступ в админку traefik
basicauth=""
```
