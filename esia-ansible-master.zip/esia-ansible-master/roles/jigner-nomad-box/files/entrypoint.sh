#!/bin/bash

CURRENT_LICENSE=$(cpconfig -license -view | grep -E "^([0-9A-Z]{5}-){4}[0-9A-Z]{5}$" | sed 's/-//')

set -e

NORMALIZED_LICENSE=$(echo ${CP_LICENSE} | sed 's/-//')

if [ ! -z "${NORMALIZED_LICENSE}" ] && [ "${CURRENT_LICENSE}" != "${NORMALIZED_LICENSE}" ]; then
  cpconfig -license -set "${CP_LICENSE}"
fi

echo "Current CryptoPro CSP license:"
cpconfig -license -view
echo

exec jigner_entrypoint $@
