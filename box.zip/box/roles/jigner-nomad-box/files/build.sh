#!/bin/bash

set -ex

export BASE_IMAGE=${BASE_IMAGE:-}
export DOCKER_REGISTRY=${DOCKER_REGISTRY:-}

JAVA_CSP_FILE=$(ls java-csp-*.zip | head -n1)
LINUX_AMD64_DEB_FILE=$(ls linux-amd*.tgz | head -n1)

docker build \
    --tag ${DOCKER_REGISTRY}/jigner-jcsp \
    --build-arg BASE_IMAGE=${BASE_IMAGE} \
    --build-arg JAVA_CSP_FILE=${JAVA_CSP_FILE} \
    --build-arg LINUX_AMD64_DEB_FILE=${LINUX_AMD64_DEB_FILE} \
    -f Dockerfile .

docker push ${DOCKER_REGISTRY}/jigner-jcsp
